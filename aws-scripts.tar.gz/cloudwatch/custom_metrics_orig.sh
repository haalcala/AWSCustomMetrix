#!/bin/bash

export JAVA_HOME=/usr/lib/jvm/jre
export PATH=$PATH:$JAVA_HOME/bin
export EC2_REGION=__EC2_REGION__
export AWS_CLOUDWATCH_HOME=$HOME/aws-scripts/cloudwatch
export PATH=$PATH:$AWS_CLOUDWATCH_HOME/bin
export AWS_CREDENTIAL_FILE=$AWS_CLOUDWATCH_HOME/.credential

#####Config###################
# P~DInstanceId
InstanceId="`curl -s 'http://169.254.169.254/latest/meta-data/instance-id'`"

#Memory
memtotal=`free -m | grep 'Mem' | tr -s ' ' | cut -d ' ' -f 2`
memfree=`free -m | grep 'buffers/cache' | tr -s ' ' | cut -d ' ' -f 4`
let "memused=100 - memfree * 100 / memtotal"

#LoadAverage
loadave1=`uptime | tr -s ' ' | cut -d ' ' -f 11 | cut -d ',' -f 1`
steal=`vmstat | tail -1 | tr -s ' ' | cut -d ' ' -f 18`

#diskUsage
l_num=1
disk_max=0
df_result=/tmp/disk_usage.txt
disk_describe=/tmp/disk_describe.txt

if [ -a $df_result ]; then
 rm -f $df_result
fi

df -k>$disk_describe

exec 3<$disk_describe
while read FL 0<&3
do
 if [ $l_num -eq 1 ] ; then
 l_num=`expr $l_num + 1`
 else
 echo $FL | grep /dev/ | tr -s ' ' | cut -d ' ' -f 5 | sed -e s/%// >> $df_result
 fi
done
exec 3<&-

while read LINE; do
 if [ $disk_max -lt $LINE ] ; then
 disk_max=`expr $LINE`
 fi
done<$df_result

#####Execute###################
#WebSocketCount
# wst=`netstat -an |grep EST | grep 8081 | wc -l`

#UsedMemoryPercent
echo 'MemoryUtilization'
mon-put-data --namespace "Custom Metrix" --metric-name "MemoryUtilization" --dimensions "InstanceId=$InstanceId" --value "$memused" --unit "Percent"

#LoadAverage
echo 'LoadAverage'
mon-put-data --namespace "Custom Metrix" --metric-name "LoadAverage" --dimensions "InstanceId=$InstanceId" --value "$loadave1" --unit "Count"

#DiskUsage
echo 'DiskSpaceUtilization'
mon-put-data --namespace "Custom Metrix" --metric-name "DiskSpaceUtilization" --dimensions "InstanceId=$InstanceId" --value "$disk_max" --unit "Percent"

#WebSocketCount
# echo 'WebSocketCount'
# mon-put-data --namespace "Custom Metrix" --metric-name "WebSocketCount" --dimensions "InstanceId=$InstanceId" --value "$wst" --unit "Percent"
